package com.book;

import java.sql.*;

public class BookDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/book_management";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Gautam@1234";

    public boolean addBook(String title, String author, String isbn) {
        boolean success = false;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String sql = "INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, author);
            stmt.setString(3, isbn);
            int rows = stmt.executeUpdate();
            success = (rows > 0);
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }
}
