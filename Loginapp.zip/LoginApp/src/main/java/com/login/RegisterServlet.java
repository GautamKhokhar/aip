package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/book_management", "root", "Gautam@1234");

            String sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, password);

            int i = ps.executeUpdate();
            con.close();

            if (i > 0) {
                res.sendRedirect("login.jsp?registered=1");
            } else {
                res.getWriter().println("<h3>❌ Registration failed. Try again.</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
