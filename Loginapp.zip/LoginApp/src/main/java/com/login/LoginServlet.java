package com.login;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/book_management", "root", "Gautam@1234");

            PreparedStatement adminStmt = con.prepareStatement(
                "SELECT * FROM admin WHERE email = ? AND password = ?");
            adminStmt.setString(1, email);
            adminStmt.setString(2, password);

            ResultSet adminRs = adminStmt.executeQuery();

            if (adminRs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("adminName", adminRs.getString("email"));
                session.setAttribute("email", email);
                session.setAttribute("role", "admin");
                session.setMaxInactiveInterval(3600);

                res.sendRedirect("admin_dashboard.jsp");
                return;
            }

            PreparedStatement userStmt = con.prepareStatement(
                "SELECT * FROM users WHERE email = ? AND password = ?");
            userStmt.setString(1, email);
            userStmt.setString(2, password);

            ResultSet userRs = userStmt.executeQuery();

            if (userRs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("username", userRs.getString("username"));
                session.setAttribute("email", userRs.getString("email"));
                session.setAttribute("role", "user");
                session.setMaxInactiveInterval(3600);

                res.sendRedirect("home.jsp");
            } else {
                out.println("<h3 style='color:red;'>Login Failed! Invalid credentials.</h3>");
                System.out.println("❌ Login failed for email: " + email);
            }

            con.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }
}
